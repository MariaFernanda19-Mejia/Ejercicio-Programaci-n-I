package co.edu.uniquindio.universidad;
import co.edu.uniquindio.universidad.model.Estudiante;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or

import java.util.ArrayList;

// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static Estudiante CrearEstudiante(String nombre,
                                             int edad, String correo, String semestre, double nota1, double nota2, double nota3) {
        return new Estudiante(nombre, edad, correo, semestre, nota1, nota2, nota3);


    }

    public static void main(String[] args) {

        Estudiante estudiante1 = CrearEstudiante("Pepito", 16, "pepito@gmail.com", "I", 4.5, 3.5, 4.0);
        Estudiante estudiante2 = CrearEstudiante("Sofía", 17, "sofiaBuritica@gmail.com", "I", 5.0, 4.0, 4.2);
        Estudiante estudiante3 = CrearEstudiante("Juan", 17, "juan@gmail", "I", 2.7, 0.6, 2.5);


    }
}