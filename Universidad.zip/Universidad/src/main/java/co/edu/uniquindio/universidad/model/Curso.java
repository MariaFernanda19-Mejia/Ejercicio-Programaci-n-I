package co.edu.uniquindio.universidad.model;

import java.util.ArrayList;

public class Curso {
    private String nombre;
    private String semestre;
    private String grupo;
    private int creditos;
    private String jornada;
    private ArrayList<Estudiante> estudiantes;

    Curso(String nombre, String semestre, String grupo, int creditos, String jornada){
        this.nombre=nombre;
        this.semestre=semestre;
        this.grupo=grupo;
        this.creditos=creditos;
        this.jornada=jornada;
    }
    public Curso(){

    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }

    public String getSemestre(){
        return semestre;
    }
    public void setSemestre(String semestre){
        this.semestre=semestre;
    }
    public String getGrupo(){
        return grupo;
    }
    public void setGrupo(String grupo){
        this.grupo=grupo;
    }
    public int getCreditos(){
        return creditos;
    }
    public void setCreditos(int creditos){
        this.creditos=creditos;
    }
    public String getJornada(){
        return jornada;
    }
    public void setJornada(String jornada){
        this.jornada=jornada;
    }

}

