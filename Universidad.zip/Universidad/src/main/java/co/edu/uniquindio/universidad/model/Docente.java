package co.edu.uniquindio.universidad.model;


public class Docente {
    public static final double NOTADEAPROBACION = 3.0;
    private String nombre;
    private String edad;
    private String correo;

    public Docente(String nombre, String edad, String correo) {
        this.nombre = nombre;
        this.edad = edad;
        this.correo = correo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return this.edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getCorreo() {
        return this.correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double calcularDefinitivaEstudiante(Estudiante estudiante) {
        double calculoNota = 0;
        calculoNota = (estudiante.getNota1() + estudiante.getNota2() + estudiante.getNota3()) / 3;
        return calculoNota;
    }

    public double calcularPromedioEstudiante(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        double promedioCurso = 0;
        promedioCurso = ((estudiante1.calcularDefinitiva() + estudiante2.calcularDefinitiva() + estudiante3.calcularDefinitiva()) / 3);
        return promedioCurso;
    }

    public int calcularEdad(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        int edadCurso = 0;
        edadCurso = (estudiante1.getEdad() + estudiante2.getEdad() + estudiante3.getEdad()) / 3;
        return edadCurso;
    }

    public double calcularNotaPromedio(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        return (estudiante1.getNota1() + estudiante2.getNota2() + estudiante3.getNota3()) / 3;
    }

    public double calcularDefinitivaMenor(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        double definitivaMenor = estudiante1.calcularDefinitiva();
        if (estudiante2.calcularDefinitiva() < definitivaMenor) {
            definitivaMenor = estudiante2.calcularDefinitiva();
        }
        if (estudiante3.calcularDefinitiva() < definitivaMenor) {
            definitivaMenor = estudiante3.calcularDefinitiva();
        }
        return definitivaMenor;
    }

    public int calcularNotaAprobacion(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        int aprobacion = 0;
        if (estudiante1.calcularDefinitiva() >= NOTADEAPROBACION) aprobacion++;
        if (estudiante2.calcularDefinitiva() >= NOTADEAPROBACION) aprobacion++;
        if (estudiante3.calcularDefinitiva() >= NOTADEAPROBACION) aprobacion++;
        return aprobacion;
    }

    public double porcentajeAprobados(int aprobacion) {
        return (aprobacion * 100.0) / 3;
    }

    public int calcularNotaDesaprobados(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        int desaprobados = 0;
        if (estudiante1.calcularDefinitiva() < NOTADEAPROBACION) desaprobados++;
        if (estudiante2.calcularDefinitiva() < NOTADEAPROBACION) desaprobados++;
        if (estudiante3.calcularDefinitiva() < NOTADEAPROBACION) desaprobados++;
        return desaprobados;
    }

    public double porcentajeDesaprobados(int desaprobados) {
        return (desaprobados * 100.0) / 3;
    }

    public int obtenerEstudiantesMayor4(Estudiante estudiante1, Estudiante estudiante2, Estudiante estudiante3) {
        int contador = 0;
        if (estudiante1.calcularDefinitiva() > 4.0) contador++;
        if (estudiante2.calcularDefinitiva() > 4.0) contador++;
        if (estudiante3.calcularDefinitiva() > 4.0) contador++;
        return contador;
    }
    public double calcularNotaMaxima

}




