package co.edu.uniquindio.universidad.model;

public class Estudiante {

        private String nombre;
        private int edad;
        private String correo;
        private String semestre;
        private double nota1;
        private double nota2;
        private double nota3;

        public Estudiante(String nombre, int edad, String correo, String semestre, double nota1, double nota2, double nota3) {
            this.nombre= nombre;
            this.edad= edad;
            this.correo= correo;
            this.semestre= semestre;
            this.nota1= nota1;
            this.nota2= nota2;
            this.nota3= nota3;

        }
        public Estudiante(){

        }

        public String getNombre(){
            return this. nombre;
        }
        public void setNombre(String nombre){
            this.nombre=nombre;
        }
        public int getEdad(){
            return this.edad;
        }
        public void setEdad(int edad){
            this.edad=edad;
        }
        public String getCorreo(){
            return this.correo;
        }
        public void setCorrreo(String correo){
            this.correo=correo;
        }
        public String getSemestre(){
            return this.semestre;
        }
        public void setSemestre(String semestre){
            this.semestre=semestre;
        }
        public double getNota1(){
            return this.nota1;
        }
        public void setNota1(double nota1){
            this.nota1=nota1;
        }
        public double getNota2(){
            return this.nota2;
        }
        public void setNota2(double nota2){
            this.nota2=nota2;
        }
        public double getNota3(){
            return this.nota3;

        }
        public double calcularDefinitiva(){
            double Definitiva=0;
            Definitiva=(nota1+nota2+nota3)/3;
            return Definitiva;
        }




    }

